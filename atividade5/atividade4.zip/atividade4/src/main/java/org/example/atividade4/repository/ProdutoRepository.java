package org.example.atividade4.repository;

public class ProdutoRepository {
}
